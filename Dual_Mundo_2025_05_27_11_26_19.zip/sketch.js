let tractorX = 50;
let milhos = [];
let cityBuildings = [];
let cityPeople = [];
let cityTrees = [];
let farmTrees = [];

function setup() {
  createCanvas(800, 400);


  for (let x = 10; x < width / 2; x += 30) {
    milhos.push({ x: x, y: 250, harvested: false });
  }

  let colors = [[200, 0, 0], [0, 0, 200], [0, 200, 0], [200, 200, 0]];
  for (let x = width / 2 + 50; x < width; x += 100) {
    cityBuildings.push({ x: x, y: 200, w: 60, h: random(80, 150), color: random(colors) });
  }


  for (let x = width / 2 + 30; x < width; x += 90) {
    cityTrees.push({ x: x, y: 250 });
  }


  for (let x = 30; x < width / 2 - 30; x += 90) {
    farmTrees.push({ x: x, y: 220 });
  }


  let skinColors = [[255, 204, 153], [200, 150, 100], [150, 100, 50]];
  let clothingColors = [[255, 0, 0], [0, 0, 255], [0, 255, 0], [255, 255, 0]];
  for (let i = 0; i < 5; i++) {
    cityPeople.push({
      x: random(550, 750),
      y: 350,
      cartX: random(-10, 10),
      skinColor: random(skinColors),
      clothingColor: random(clothingColors)
    });
  }
}

function draw() {
  background(180);

  stroke(0);
  line(width / 2, 0, width / 2, height);

  fill(34, 139, 34);
  rect(0, 200, width / 2, 200);


  fill(255, 223, 0);
  for (let i = 0; i < milhos.length; i++) {
    if (!milhos[i].harvested) {
      ellipse(milhos[i].x, milhos[i].y, 20, 40);
    }
  }

  fill(150, 0, 0);
  rect(tractorX, 270, 50, 30);
  fill(0);
  ellipse(tractorX + 10, 300, 20, 20);
  ellipse(tractorX + 40, 300, 20, 20);

  tractorX += 2;
  for (let i = 0; i < milhos.length; i++) {
    if (tractorX + 50 > milhos[i].x && tractorX < milhos[i].x) {
      milhos[i].harvested = true;
    }
  }

  if (tractorX > width / 2) {
    tractorX = -50;
    for (let i = 0; i < milhos.length; i++) {
      milhos[i].harvested = false;
    }
  }


  fill(165, 42, 42);
  rect(100, 150, 80, 60);
  fill(200);
  triangle(100, 150, 180, 150, 140, 110);

  for (let tree of farmTrees) {
    fill(139, 69, 19);
    rect(tree.x, tree.y, 20, 50);
    fill(34, 139, 34);
    ellipse(tree.x + 10, tree.y - 20, 50, 50);
  }


  fill(200);
  rect(width / 2, 200, width / 2, 200);

 
  for (let building of cityBuildings) {
    fill(building.color);
    rect(building.x, building.y - building.h, building.w, building.h);
  }

  for (let tree of cityTrees) {
    fill(139, 69, 19);
    rect(tree.x, tree.y, 20, 50);
    fill(34, 139, 34);
    ellipse(tree.x + 10, tree.y - 20, 50, 50);
  }

  for (let person of cityPeople) {
    fill(person.skinColor);
    ellipse(person.x, person.y, 20, 20);
    fill(person.clothingColor);
    rect(person.x - 5, person.y + 10, 10, 20);
    fill(100);
    rect(person.x + person.cartX, person.y + 15, 15, 10);
    rect(person.x + person.cartX + 2, person.y + 20, 10, 10);
  }
}
